/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.taf;

/**
 *
 * @author User
 */

import java.util.Scanner;

public class Taf 
{

    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);   
        Universidade univ = new Universidade();
        //Universidade univ = new Universidade("ITA", "Instituto Tecnológico de Aeronáutica", "Engenharia da Computação", 0);
        Curso c1 = new Curso(univ);
        Instituto inst = new Instituto();
        String univNome, univSigla, instNome, instSigla, c1Nome ;
        int c1Cod;
        
        //colocando os dados para c1     
        c1.setInstituto(inst);
        
        StringBuilder sb = new StringBuilder();
          sb.append("Respostas padrões:");
          sb.append("\nNome da universidade: Faculdade Estadual de Tecnologia");
          sb.append("\nSigla da universidade: FATEC");
          sb.append("\nNome do Instituto: Centro Paula Souza");
          sb.append("\nSigla do Instituto: CPS");
          sb.append("\nNome do Curso: Analise e Desenvolvimento de Sistemas");
          sb.append("\nCódigo do Curso: 020\n\n");

        // Printando as informações concatenadas
          System.out.println(sb.toString());
        
        System.out.print("Digite o nome da universidade (ou pressione Enter para usar o nome padrão): ");
        univNome = scanner.nextLine().trim();
        if (univNome.isEmpty()) 
        {
            //univ.setNome("Faculdade Estadual de Tecnologia");
            System.out.println("Nome da universidade: " + univ.getNome());
        } 
        else
        {
        System.out.println("Nome da universidade: " + univNome);
        }

        System.out.print("Digite a sigla da universidade (ou pressione Enter para usar a sigla padrão): ");
        univSigla = scanner.nextLine().trim();
        if (univSigla.isEmpty()) 
        {
           //univ.setSigla("FATEC");
           System.out.println("Sigla da universidade: " + univ.getSigla());
        }
        else
        {
        System.out.println("Sigla da universidade: " + univSigla);
        }

        System.out.print("Digite o nome do instituto (ou pressione Enter para usar o nome padrão): ");
        instNome = scanner.nextLine().trim();
        if (instNome.isEmpty()) 
        {
            inst.setNomeInstituto("Centro Paula Souza");
            System.out.println("Nome do instituto: " + inst.getNomeInstituto());
        }
        else
        {
            System.out.println("Nome do instituto: " + instNome);
        }

        System.out.print("Digite a sigla do instituto (ou pressione Enter para usar a sigla padrão): ");
        instSigla = scanner.nextLine().trim();
        if (instSigla.isEmpty()) 
        {
            inst.setSiglaInstituto("CPS");
            System.out.println("Sigla do instituto: " + inst.getSiglaInstituto());
        }
        else
        {
        System.out.println("Sigla do instituto: " + instSigla);
        }

        System.out.print("Digite o nome do curso (ou pressione Enter para usar o nome padrão): ");
        c1Nome = scanner.nextLine().trim();
        if (c1Nome.isEmpty()) 
        {
            c1.setNomeCurso("Analise e Desevolvimento de Sistemas");
            System.out.println("Nome do curso: " + c1.getNomeCurso());
        }
        else
        {
        System.out.println("Nome do curso: " + c1Nome);
        }

        System.out.print("Digite o código do curso (ou pressione Enter para usar o código padrão): ");
        c1Cod = scanner.nextInt();
        if (c1Cod == 0) 
        {
             c1.setCodCurso(20);
             System.out.println("Código do curso: " + String.format("%03d", c1.getCodCurso()));
        }
        else
        {
        System.out.println("Código do curso: " + String.format("%03d", c1Cod));
        }
        scanner.close();
    }
}
