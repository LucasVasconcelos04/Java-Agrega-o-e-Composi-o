/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taf;

/**
 *
 * @author User
 */
public class Curso 
{
    private String nomeCurso;
    private int codCurso;
    private Instituto instituto;
    private Universidade universidade;
    
    public Curso(Universidade universidade)
    {
            this.universidade = universidade; //Aqui explica que a "universidade" que eu quero utilizar não é a da classe.
    }
    
    public String getNomeCurso() {
        return nomeCurso;
    }

    public void setNomeCurso(String nomeCurso) {
        this.nomeCurso = nomeCurso;
    }

    public int getCodCurso() {
        return codCurso;
    }

    public void setCodCurso(int codCurso) {
        this.codCurso = codCurso;
    }

    public Instituto getInstituto() {
        return instituto;
    }

    public void setInstituto(Instituto instituto) {
        this.instituto = instituto;
    }
    
     public Curso()
    {
        nomeCurso = "";
        codCurso = 0;
    }
    
    public Curso(String nomeInst)
    {
        //instanciar o Instituto
        instituto = new Instituto();
        //atribuir no objeto Instituto
        instituto.setNomeInstituto(nomeInst);
    }
}
