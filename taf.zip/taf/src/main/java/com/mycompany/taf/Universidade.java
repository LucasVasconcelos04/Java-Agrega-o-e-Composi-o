/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taf;

/**
 *
 * @author User
 */
public class Universidade 
{
    private Curso curso;
    private Instituto instituto;
    private String sigla, nome;

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public Universidade()
    {
        nome = "";
        sigla = "";
    }
    
    public Universidade(String siglaInstituto, String nomeInstituto, String nomeCurso, int codCurso )
    {
        Instituto inst = new Instituto();
        inst.setNomeInstituto(nomeInstituto);
        inst.setSiglaInstituto(siglaInstituto);
        
        Curso c1 = new Curso();
        c1.setNomeCurso(nomeCurso);
        c1.setCodCurso(codCurso); 
        
        nome = "";
        sigla = "";
    }
}
