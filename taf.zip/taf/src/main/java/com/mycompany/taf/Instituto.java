/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.taf;

/**
 *
 * @author User
 */
public class Instituto 
{
    private String siglaInstituto, nomeInstituto;
    private Universidade universidade;

    public Universidade getUniversidade() {
        return universidade;
    }

    public void setUniversidade(Universidade universidade) {
        this.universidade = universidade;
    }
    

    public String getSiglaInstituto() {
        return siglaInstituto;
    }

    public void setSiglaInstituto(String siglaInstituto) {
        this.siglaInstituto = siglaInstituto;
    }

    public String getNomeInstituto() {
        return nomeInstituto;
    }

    public void setNomeInstituto(String nomeInstituto) {
        this.nomeInstituto = nomeInstituto;
    }
    
    
}
